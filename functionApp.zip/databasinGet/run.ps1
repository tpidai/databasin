using namespace System.Net
using namespace Microsoft.Azure.Powersehhll.Cmdlets.App.Models


# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

class Properties {
    [string]$domain_name
    [string]$domain_ip_address
    [string]$databasin_login_url
    Properties([string]$domain_name, [string]$domain_ip_address, [string]$databasin_login_url) {
        $this.domain_name = $domain_name
        $this.domain_ip_address = $domain_ip_address
        $this.databasin_login_url = $databasin_login_url
    }
}
class databasininstances {
    # Properties
    [string]$id
    [Properties[]]$properties
    [string]$name
    [string]$type
    

    # Constructor
    databasininstances([string]$id,[string]$name, [Properties]$value) {
        $this.type = "Microsoft.CustomProviders/resourceProviders/databasininstances"
        $this.id = $id
        $this.Name = $name
        $this.properties=$value
        # $this.value = $value
    }

    # # Method
    # [string]ToString() {
    #     return "Name: $($this.Name), Value: $($this.Value)"
    # }
}

    $rgName = "databasin-test02-rg" #$env:RESOURCE_GROUP_NAME
    if ([string]::IsNullOrWhiteSpace($rgName)) {
        throw "Environment variable 'RESOURCE_GROUP_NAME' is not set or empty."
    }
    
    try {
        $envs =az containerapp env list --resource-group $rgName | ConvertFrom-Json
    } catch {
        throw "Failed to list Container App managed environments in resource group '$rgName': $($_.Exception.Message)"
    }
    if (-not $envs) {
        Write-Warning "No AzContainerApp managed environments found in resource group '$rgName'."
        return $null
    }

    $firstEnv= $envs | Select-Object -First 1
    write-host "name" $firstEnv.name
    $staticIp = $firstEnv.properties.staticIP
    if ([string]::IsNullOrWhiteSpace($staticIp)) {
         Write-Warning "Container App managed environment '$($firstEnv.Name)' in resource group '$rgName' has an empty static IP address."
         return $null
    }
    $defaultDomain =$firstEnv.properties.defaultDomain
    if ([string]::IsNullOrWhiteSpace($defaultDomain)) {
        Write-Warning "Container App managed environment '$($firstEnv.Name)' in resource group '$rgName' has an empty default domain."
         return $null
    }
    $databasinLoginUrl ="{0}{1}{2}" -f "https://databasin-ui.", $firstEnv.DefaultDomain, "/login"

    $props =[Properties]::new($defaultDomain, $staticIp,$databasinLoginUrl )
    # $id= $firstEnv.id.replace("/Microsoft.App/","/Microsoft.CustomProviders/resourceProviders/databasinprovider/").Replace("/managedEnvironments/","/databasininstances/")
    # $name=$firstEnv.name
    $obj = [databasininstances]::new($firstEnv.id, $firstEnv.name,$props)
    $wrapper = @($obj)
    $body=@{
        value= $wrapper
    } | ConvertTo-Json -Depth 4
    

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body =  $body
})
