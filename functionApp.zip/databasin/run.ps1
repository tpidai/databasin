using namespace System.Net
using namespace Microsoft.Azure.Powersehhll.Cmdlets.App.Models


# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

class Properties {
    [string]$domain_name
    [string]$domain_ip_address
    [string]$databasin_login_url
    Properties([string]$domain_name, [string]$domain_ip_address, [string]$databasin_login_url) {
        $this.domain_name = $domain_name
        $this.domain_ip_address = $domain_ip_address
        $this.databasin_login_url = $databasin_login_url
    }
}
class databasininstances {
    # Properties
    [string]$id
    [Properties[]]$properties
    [string]$name
    [string]$type
    

    # Constructor
    databasininstances([string]$id,[string]$name, [Properties]$value) {
        $this.type = "Microsoft.CustomProviders/resourceProviders/databasininstances"
        $this.id = $id
        $this.Name = $name
        $this.properties=$value
    }

}

    $rgName = $env:RESOURCE_GROUP_NAME
    $clientId = $env:AzureWebJobsStorage__clientId

    try{ Connect-AzAccount -Identity -AccountId $clientId -ErrorAction Stop } catch {
        Write-Error "Failed to authenticate with Azure using Managed Identity: $($_.Exception.Message)"
        throw "Failed to authenticate with Azure using Managed Identity: $($_.Exception.Message)"
    }
    
    if ([string]::IsNullOrWhiteSpace($rgName)) {
        Write-Error "Environment variable 'RESOURCE_GROUP_NAME' is not set or empty."
        throw "Environment variable 'RESOURCE_GROUP_NAME' is not set or empty."
    }

    try {
        $envs = Get-AzContainerAppManagedEnv -ResourceGroupName $rgName -ErrorAction Stop
    } catch {
        Write-Error "Failed to list Container App managed environments in resource group '$rgName': $($_.Exception.Message)"
        throw "Failed to list Container App managed environments in resource group '$rgName': $($_.Exception.Message)"
    }
    if (-not $envs) {
        Write-Error "No AzContainerApp managed environments found in resource group '$rgName'."
        return $null
    }

    [Microsoft.Azure.PowerShell.Cmdlets.App.Models.ManagedEnvironment]$firstEnv= $envs | Select-Object -First 1
    $staticIp = $firstEnv.StaticIP
    if ([string]::IsNullOrWhiteSpace($staticIp)) {
        Write-Warning "Container App managed environment '$($firstEnv.Name)' in resource group '$rgName' has an empty static IP address."
        return $null
    }
    $defaultDomain =$firstEnv.DefaultDomain
    if ([string]::IsNullOrWhiteSpace($defaultDomain)) {
        Write-Warning "Container App managed environment '$($firstEnv.Name)' in resource group '$rgName' has an empty default domain."
        return $null
    }
    $databasinLoginUrl ="{0}{1}{2}" -f "https://databasin-ui.", $firstEnv.DefaultDomain, "/login"

    $props =[Properties]::new($defaultDomain, $staticIp,$databasinLoginUrl )
    $id= $firstEnv.id.replace("/Microsoft.App/","/Microsoft.CustomProviders/resourceProviders/databasinprovider/").Replace("/managedEnvironments/","/databasininstances/")
    $name=$firstEnv.name
    $obj = [databasininstances]::new($id, $name, $props)
    $wrapper = @($obj)
    $body=@{
        value= $wrapper
    } | ConvertTo-Json -Depth 4
    

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body =  $body
})
